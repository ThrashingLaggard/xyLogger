﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using xyLogger.Loggers;

namespace xyLogger.Helpers.Archiver
{
    internal class xyLogArchiver
    {
        private readonly long _maxFileSize = 1000000; // 1MB?!

        public xyLogArchiver(long maxFileSize)
        {
            _maxFileSize = maxFileSize;
        }

        public string FormatForArchive(string filePath)
        {
            string archivePath = $"{filePath}_{DateTime.Now:yyyyMMdd_HHmmss}.log";
            xyLog.Log("Formatting for archive: " + archivePath);
            return archivePath;
        }

        public void MoveLogToArchiveFileIfTooBig(string filepath_)
        {
            if (File.Exists(filepath_) && new FileInfo(filepath_).Length > _maxFileSize)
            {
                string newPath = FormatForArchive(filepath_);
                try
                {
                    File.Move(filepath_, newPath);
                    xyLog.Log("Moving the log to archive was successfull");
                }
                catch (Exception ioEx)
                {
                    xyLog.ExLog(ioEx);
                }
            }
        }

        public async Task MoveLogToArchiveFileIfTooBigAsync(string filepath_)
        {
            if (File.Exists(filepath_) && new FileInfo(filepath_).Length > _maxFileSize)
            {
                string newPath = "";
                await Task.Run(() => newPath = FormatForArchive(filepath_));
                try
                {
                    await Task.Run(() => File.Move(filepath_, newPath));
                    xyLog.Log("Moving the log to archive was successfull");

                }
                catch (Exception Ex)
                {
                    xyLog.ExLog(Ex);
                }
            }
        }
    }
}
